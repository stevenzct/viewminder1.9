﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Guna.UI2.WinForms;
using System.Windows.Forms;
using System.Data.SqlClient;




namespace viewminder1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           // tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
           // tabControl1.DrawItem += new DrawItemEventHandler(tabControl1_DrawItem);

        }

        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
          //  e.DrawBackground();
           // e.Graphics.DrawString(tabControl1.TabPages[e.Index].Text, tabControl1.Font, Brushes.Black, e.Bounds, StringFormat.GenericDefault);
        }


        private void Button_Click(object sender, EventArgs e)
        {
           // throw new NotImplementedException();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void Guna2Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Guna2Panel1_Paint_1(object sender, PaintEventArgs e)
        {
            string hexColor = "#0A0C29";

            Color myColor = System.Drawing.ColorTranslator.FromHtml(hexColor);

            btnPanel.BackColor = myColor;
        }

        private void Guna2ControlBox1_Click(object sender, EventArgs e)
        {

        }

        private void Guna2ControlBox3_Click(object sender, EventArgs e)
        {

        }

        private void Guna2ControlBox2_Click(object sender, EventArgs e)
        {

        }

        private void Guna2ControlBox2_Click_1(object sender, EventArgs e)
        {

        }

        private void Guna2ControlBox3_Click_1(object sender, EventArgs e)
        {

        }

        private void Guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void Guna2HtmlLabel2_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button1_Click(object sender, EventArgs e)
        {
           


            string hexColor = "#2C81FF";

            Color myColor = System.Drawing.ColorTranslator.FromHtml(hexColor);

           

            

        }

        private void Guna2PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2ControlBox2_Click_2(object sender, EventArgs e)
        {

        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2HtmlLabel3_Click(object sender, EventArgs e)
        {

        }


        private List<Guna2Button> allButtons = new List<Guna2Button>();

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            //Sms s = new Sms();
            // s.TopLevel = false;
            // pnlContent.Controls.Add(s);
            // s.BringToFront();
            // s.Show();

            tabControl1.SelectedTab = tabPage2;



        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            // new form show 
            // Logout l = new Logout();
            //l.TopLevel = false;
            //pnlContent.Controls.Add(l);
            // l.BringToFront();
            // l.Show();
            this.Close();
            confirmLogout cl = new confirmLogout();
            cl.Show();




        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            // new form show 
            // Notification n = new Notification();
            // n.TopLevel = false;
            // pnlContent.Controls.Add(n);
            // n.BringToFront();
            //  n.Show();

            tabControl1.SelectedTab = tabPage4;
        }

        private void Guna2ControlBox3_Click_2(object sender, EventArgs e)
        {

        }

        private void BtnWatching_Click(object sender, EventArgs e)
        {
            // new form show 
            // Watching w = new Watching();
            // w.TopLevel = false;
            // pnlContent.Controls.Add(w);
            // w.BringToFront();
            // w.Show();


            tabControl1.SelectedTab = tabPage1;



        }

        private void Guna2Button1_Click_1(object sender, EventArgs e)
        {
            // new form show 
            //  Archive a = new Archive();
            // a.TopLevel = false;
            // pnlContent.Controls.Add(a);
            //  a.BringToFront();
            //  a.Show();

            tabControl1.SelectedTab = tabPage3;



        }

        private void Guna2Button7_Click(object sender, EventArgs e)
        {
            // new form show 
            //  Profile p = new Profile();
            //  p.TopLevel = false;
            //  pnlContent.Controls.Add(p);
            //  p.BringToFront();
            //  p.Show();

            tabControl1.SelectedTab = tabPage5;
        }

        private void Guna2Button1_Click_2(object sender, EventArgs e)
        {
          
        }

        private void PnlContent_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button3_Click_1(object sender, EventArgs e)
        {
           
        }

        private void Guna2PictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void Guna2HtmlLabel5_Click(object sender, EventArgs e)
        {

        }

        private void Guna2PictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void Guna2PictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void Guna2PictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void Guna2PictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void Guna2PictureBox14_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage7;
        }

        private void Guna2PictureBox15_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage6;
        }

        private void Guna2PictureBox13_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage8;
        }

        private void Guna2PictureBox12_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage9;
        }

        private void TabControl2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void Guna2PictureBox6_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage6;
        }

        private void Guna2PictureBox11_Click_1(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage6;
        }

        private void Guna2PictureBox19_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage6;
        }

        private void Guna2PictureBox5_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage7;
        }

        private void Guna2PictureBox10_Click_1(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage7;
        }

        private void Guna2PictureBox18_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage7;
        }

        private void Guna2PictureBox3_Click_1(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage8;
        }

        private void Guna2PictureBox9_Click_1(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage8;
        }

        private void Guna2PictureBox17_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage8;
        }

        private void Guna2PictureBox2_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage9;
        }

        private void Guna2PictureBox8_Click_1(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage9;
        }

        private void Guna2PictureBox16_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedTab = tabPage9;
        }

        private void Guna2CirclePictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void TabPage2_Click(object sender, EventArgs e)
        {

        }

        private void TabPage3_Click(object sender, EventArgs e)
        {

        }

        private void TabPage5_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {
          
        }

        private void Guna2Panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Label7_Click(object sender, EventArgs e)
        {
            viewVideo vd = new viewVideo();
            vd.Show();
        }

        private void Label13_Click(object sender, EventArgs e)
        {

        }

        private void Label24_Click(object sender, EventArgs e)
        {

        }

        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Guna2Button11_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button10_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button1_Click_3(object sender, EventArgs e)
        {

        }

        private void Guna2Separator7_Click(object sender, EventArgs e)
        {

        }

        private void Label20_Click(object sender, EventArgs e)
        {

        }

        private void Label21_Click(object sender, EventArgs e)
        {

        }

        private void Label22_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox21_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox20_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox19_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox18_Click(object sender, EventArgs e)
        {

        }

        private void Label19_Click(object sender, EventArgs e)
        {

        }

        private void Label17_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Separator6_Click(object sender, EventArgs e)
        {

        }

        private void Label18_Click(object sender, EventArgs e)
        {

        }

        private void Label8_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Separator3_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void Guna2HtmlLabel12_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button4_Click(object sender, EventArgs e)
        {
            //edit btn profile
            // Select tabPage10 in tabControl1
            tabControl1.SelectTab("tabPage10");
        }

        private void TabPage7_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Panel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Guna2Panel14_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Guna2Panel17_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Guna2Panel15_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Guna2HtmlLabel23_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Panel16_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Guna2HtmlLabel24_Click(object sender, EventArgs e)
        {

        }

        private void Guna2PictureBox7_Click(object sender, EventArgs e)
        {
            // Check the current visibility state of FlowLayoutPanel2
            if (guna2Panel25.Visible)
            {
                // If it's visible, hide it
                guna2Panel25.Visible = false;
            }
            else
            {
                // If it's not visible, show it
                guna2Panel25.Visible = true;
            }
        }

        private void Guna2Button17_Click(object sender, EventArgs e)
        {
            btnSms.PerformClick();
           
        }

        private void PictureBox1_Click_1(object sender, EventArgs e)
        {
            guna2Panel25.Visible = false;
        }

        private void Guna2Button18_Click(object sender, EventArgs e)
        {

            guna2Button7.PerformClick();
            guna2Panel25.Visible = false;
        }

        private void Guna2Button17_Click_1(object sender, EventArgs e)
        {

        }

        private void Guna2Button20_Click(object sender, EventArgs e)
        {
            btnSms.PerformClick();
            guna2Panel25.Visible = false;
        }

        private void Guna2Button19_Click(object sender, EventArgs e)
        {

            btnWatching.PerformClick();
            guna2Panel25.Visible = false;
        }

        private void Guna2Button21_Click(object sender, EventArgs e)
        {
  
            btnArchive.PerformClick();
            guna2Panel25.Visible = false;
        }

        private void Guna2Button22_Click(object sender, EventArgs e)
        {

            guna2Button8.PerformClick();
            guna2Panel25.Visible = false;
        }

        private void Guna2Button15_Click(object sender, EventArgs e)
        {
            //cancel edit profile btn
            // Select tabPage5 in tabControl1
            tabControl1.SelectTab("tabPage5");
        }
    }
}
